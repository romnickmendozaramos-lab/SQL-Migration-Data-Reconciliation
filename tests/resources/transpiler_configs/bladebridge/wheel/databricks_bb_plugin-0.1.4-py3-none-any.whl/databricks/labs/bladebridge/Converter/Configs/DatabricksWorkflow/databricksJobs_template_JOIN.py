print("Executing JOIN")
