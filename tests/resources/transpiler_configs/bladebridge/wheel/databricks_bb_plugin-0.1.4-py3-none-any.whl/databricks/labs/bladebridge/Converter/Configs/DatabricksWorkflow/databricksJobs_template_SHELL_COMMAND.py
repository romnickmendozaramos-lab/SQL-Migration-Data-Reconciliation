%sh

%COMMAND%